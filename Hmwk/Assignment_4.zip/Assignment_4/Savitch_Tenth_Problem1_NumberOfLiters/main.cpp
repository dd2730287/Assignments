/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on April 1, 2018, 5:07 PM
 */

#include <iostream>
using namespace std;
float const LITER = 0.264172;
float milesPerGallon(int ml, int lt);

int main ()
{
	char options;
	int lt, ml;
	do 
	{
	  cout << "Enter the number of Liters of gasoline:";
	  cin >> lt;
  cout <<"Enter the number of miles traveled by the car: ";
       cin >> ml;
	   cout << "Number of miles per gallon:"  
            << milesPerGallon(ml, lt) << endl;
		cout << "To continue, then enter 'Y':";
		cin >> options;
	} while (options == 'y' || options == 'Y');
	return 0;
}
float milesPerGallon(int m, int l)
{
	float gallons;
	gallons = LITER * l;
	return (m/gallons);
}