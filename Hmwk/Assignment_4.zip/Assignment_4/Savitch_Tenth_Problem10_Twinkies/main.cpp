/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on April 1, 2018, 8:04 PM
 */

#include <iostream>
using namespace std;

void twinkie();
bool good(int);

const int TWINKIE_COST = 350;
const int DOLLAR = 100, QUARTER = 25, DIME = 10, NICKEL = 5;


int main()
{
 char ans;
 do
 {
       twinkie();
      cout <<  "Would you like to have another twinkie? (y or n) ";
      cin >> ans;
 }while (ans == 'y' || ans == 'Y');
 
 return 0;
}

void twinkie()
{
     int total_coins = 0, coin, change;
     
     do
     {
           
           cout << "Enter a coin or dollar amount: ";
           cin >> coin;
           
           
           if (good(coin))
           {
                  total_coins += coin; 
                  cout << "You've added " << total_coins << " cents. " << endl;
                  cout << "You need " << TWINKIE_COST - total_coins << " more. " << endl;
           }
           else
           {
               cout << "Not a valid coin."; 
           }
     } while (total_coins < TWINKIE_COST);
     cout << "Enjoy your twinkie! ";
     change = total_coins - TWINKIE_COST;
     if (change > 0)
     {
     cout << "Your change is: " << change;          
     }
     
     return;
}

bool good(int c)
{
     if(c==NICKEL || c==DIME || c==QUARTER || c==DOLLAR)
             return true;
     else
             return false;
}