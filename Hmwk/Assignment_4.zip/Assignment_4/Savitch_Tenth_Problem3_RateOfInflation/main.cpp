/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on April 1, 2018, 5:44 PM
 */

#include <iostream>
#include <cmath>
using namespace std;

float calculate_inflation(float, float);
int main()
{
   float yearAgo_price;
   float currentYear_price;
   float inflation_rate;
   char again;

 do{
      cout << "Enter the item price one year ago (or zero to quit) : " << endl;
      cin >> yearAgo_price;

      cout << "Enter the item price today: " << endl;
      cin >> currentYear_price;

       cout.setf(ios::fixed);
       cout.setf(ios::showpoint);
       cout.precision(2);

       inflation_rate=calculate_inflation(yearAgo_price, currentYear_price);
       cout << "The inflation rate is " << (inflation_rate*100) << " percent." << endl;

       cout << "Do you want to continue (Y/N)?" << endl;
       cin >> again;

      }while((again =='Y') || (again =='y'));

          return 0;
}

   float calculate_inflation (float yearAgo_price, float currentYear_price)
   {
      return ((currentYear_price-yearAgo_price)/ yearAgo_price);
   }