/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on April 1, 2018, 6:25 PM
 */

#include <stdio.h> 
#define G (6.673E-8) 
int main( int argc, const char * argv[] ) { 
    char answer; 
    double mass1, mass2, distance; 
    double gravity; 
    do { 
        printf("Enter the mass of the first body (in grams): "); 
        scanf("%lf", &mass1); 
        printf("Enter the mass of the second body (in grams): "); 
        scanf("%lf", &mass2); 
        printf("Enter the distance between the two bodies of mass (in cm): "); 
        scanf("%lf", &distance); 
        gravity = (G * mass1) * mass2 / (distance*distance); 
        printf("The gravitational force between the two objects is %lg dynes\n", gravity ); 
        printf("Do you wish to perform another calculation? (y/n): "); 
        scanf(" %c", &answer); 
    } while ( answer == 'y' || answer == 'Y' ); 
    return 0; 
} 