/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel 
 *
 * Created on April 1, 2018, 7:26 PM
 */

#include <iostream>

using namespace std;

float hat(float,float);

float jacket(float,float,int);

float waist(float,float,int);

int main ()
{
float height, weight;
int age;
char answer;

cout.setf(ios::fixed);
cout.setf(ios::showpoint);
cout.precision(2);

do
{
cout<< "Enter the customer's height in inches: ";
cin>>height;
cout<< "Enter the customer's weight in pounds: ";
cin>>weight;
cout<< "Enter the customer's age: ";
cin>>age;
cout<< "\tYour Hat size: " << hat(weight ,height) << "\tYour Jacket size: "<< jacket( height, weight, age) << "\tYour Waist size: "<< waist( height, weight, age)<< "\n \nWould you like to continue (y/n)? ";
cin>>answer;
}while(toupper(answer) == 'Y');
return 0;
}

float hat(float weight ,float height)
{
return ((weight/height) * 2.9);
}

float jacket(float height,float weight,int age)
{ 
float size;
int j;
if (age>=30)
{
if((age % 10) !=0)
age = age-(age%10);
j= (age-30)/10;
size =((height * weight) / 288)+((1.0/8)*j);
}
else
size =((height * weight) / 288);
return size;
}

float waist(float height,float weight,int age)
{
float size2;
int k;
if(age >= 28)
{
if((age % 2) !=0)
age = age-(age%2);
k = (age-28)/2;
size2 = (weight/(5.7))+( (1.0/10)*k);
}
else 
size2 = weight / (5.7);
return size2;
}