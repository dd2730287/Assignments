/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on April 1, 2018, 6:50 PM
 */

#include <cstdlib>
#include <iostream>

using namespace std; 

float max(float num1, float num2)// Takes in two double parameters.
{   // Calculates the max of two numbers
    if(num1 > num2)
    {
        return num1; // Returns number 1 if it is the largest.
    }
    else
    {
        return num2; // Returns number 2 if it is the largest.
    }
}
// Takes in three double parameters. 
float max(float num1, float num2, float num3)
{   // Also calculates the max but if there is three numbers to compare.
    if(num1 > num2 and num1 > num3)
    {
        return num1; // Returns number 1 if it is greater than number 2 and 3.
    }
    else if(num2 > num1 and num2 > num3)
    {
        return num2; // Returns number 2 if it is greater than number 1 and 3.
    }
    else if(num3 > num1 and num3 > num2)
    {
        return num3; // Returns number 3 if it is greater than number 1 and 2.
    }
    else
    {
        cout << "Fix";
        return num3;
    }
}

float iceCreamShare(float iceCream, int people = 1)
{
    return iceCream / people;
}
int main(int argc, char** argv) {
    int choice;
    do{
    cout << "---------------::Main Menu::---------------\n";
    cout << "Please choose one of the following options.\n";
    cout << "--------------1) Max Function--------------\n";
    cout << "--------------2) Ice Cream-----------------\n";
    cout << "--------------3) Quit----------------------\n";
    cin >> choice;
    switch(choice)
    {
        case 1:
            float num1, num2, num3;
            cout << "Please enter two numbers to find the max number:";
            cin >> num1 >> num2;
            cout << max(num1, num2);
            cout << "Please enter three numbers to find the max:";
            cin >> num1 >> num2 >> num3;
            cout << max(num1, num2, num3);
            break; 
        case 2:
            float iceCream;
            int people;
            cout << "Enter the amount of ice cream in pints: ";
            cin >> iceCream;
            cout << "Enter the number of people: ";
            cin >> people;
            cout << "Each person should get " << iceCreamShare(iceCream, people)
                 << " pint(s) of ice cream.\n";
            break;
            
    }
    }while(choice != 3);
    return 0;
}
