/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on April 1, 2018, 5:17 PM
 */

#include <iostream>
using namespace std;

float StockPrice (int whole, int nr, int dr, int stock);
int main ()
{

   int whole, nr, dr, stock;
   float stockVal = 0;
   char Continue;
   do
   {
       cout<<"Enter stock price and number of shares, please."<<endl;
       cout<<"Enter price as integers: dollars, numberator, denominator"<<endl;
       cin>>whole;
       cin>>nr;
       cin>>dr;
       cout<<"Enter number of shares held. "<<endl;
       cin>>stock;
      
       stockVal = StockPrice (whole, nr, dr, stock);
       cout<<""<<stock<< " shares of stock with market price "<<whole<<" "<<nr<<"/"<<dr<<endl;
       cout<<"Have a of value $ "<<stockVal<<endl;
       cout<<"Press 'y' or 'Y' to repeat calculations for different variables? "<<endl;
       cin>>Continue;
   }  
  
   while (Continue == 'y' || Continue == 'Y');
   system("pause");
}
   float StockPrice (int whole, int nr, int dr, int stock)
   {
       float price;
       price=static_cast<float>(whole * dr + nr)/(dr * stock);
       return price ;
   }