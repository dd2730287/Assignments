/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 19, 2018, 4:40 PM
 */

#include <iostream>
#include <cmath>

using namespace std;

int main()
{

  for (int x = 3; x <= 100; x++)
  {
    bool prime = true;
    for (int y = 2; y <= (x - 1); y++)
    {
      if ((x % y) == 0)
      {
          prime = false;
          break;
      }
    }

    if (prime == true)
    { 
      cout<<x<<endl;
    } 
  }

  return 0;
}