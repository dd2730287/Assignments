/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 19, 2018, 4:51 PM
 */

#include <iostream>
#include <cmath>
using namespace std;

int main ()
{
float y = 62.4;
float w; 
float r; 
double V; 
double Fb; 
char answer; 
do 
{
cout<< "Please enter weight of the object in lbs and press enter: " <<endl;
cin>> w; 
cout<< "Please enter radius of the object in feet and press enter: " << endl;

cin >> r ; 
V=(4/3)*(M_PI)*(pow(r,3));
Fb = (V)*(y); 
{
if (Fb >= w)
{
cout << "This Sphere will float! :) " << endl; 

}
else 
{
cout << "This Sphere will sink! :( " << endl; 
}
}
cout << "Calculate another buoyancy? (y/n) " << endl; 

cin >> answer; 
} while ((answer == 'y' || answer == 'Y'));
cout << "End of Testing!" << endl; 

return 0; 
}
