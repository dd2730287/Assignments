/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 19, 2018, 5:43 PM
 */



#include<iostream>

using namespace std;

double factorialTable(double *table, int n);

int main()

{
    double facts[101];
    int i;

    factorialTable (facts, 100);

    for (i=1; i<101;i++)

        {

        cout << i<< '\t' << facts[i] <<'\n';

        }

    return 0;

}

 
double factorialTable(double *table, int n)

{

    double retValue;

    if (n>=1)

    {

        if (n==1) 

        {

            table[n] = 1;

            retValue = 1;

        } else

        {

            retValue = n * factorialTable(table, n-1);

            table[n] = retValue;

        }

    } else { retValue = 0; }

    return retValue;

}

