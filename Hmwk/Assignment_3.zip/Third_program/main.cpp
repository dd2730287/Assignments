/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 19, 2018, 4:33 PM
 */

#include <iostream>
using namespace std;
double minimum(double total_amount); 
 
int main()
{

      char goOn = 'y';


      double total_amount, interest, minimum_amount, account_balance;

      do

      {

          cout << "Please enter in the account balance.\n";

          cin >> account_balance;
           if (account_balance <= 1000)

           

           {

               interest = .015 * account_balance;

               total_amount = interest + account_balance;

           }

           if(account_balance > 1000)

      {

           interest = .01 * account_balance;
           total_amount = interest + account_balance;

      }

      minimum_amount = minimum(total_amount);

       cout << "Your total amount is " << total_amount << endl;

       cout << "Your interest due is " << interest << endl;

       cout << "Your minimum payment is " << minimum_amount << endl;

       cout << "Would you like to continue? (y or n): ";//Consider this.

       cin >> goOn;

       if (goOn == 121 || goOn == 89)//You need to study ASCII values. A 121 is a lower case y and a 89 is an

       //Uppercase y. Any questions just post me.

       cout << "***************************************\n";//This will separate the loops.

       // The \n symbol is the equivalent as the endl

       else if (goOn != 121 && goOn != 89)//So if the user didn't enter a y then quite the program.
       {
           cout << "\nHave a nice day.\n";

          system("PAUSE");//This is a nice feature but is not necessary.

          exit(1);//Terminates your code.

       }

    }

     while (goOn == 121 || goOn == 89);

return 0;

}

 

double minimum(double total_amount)//This is a nice function.

{

    double minimum = 0.0;

    if (total_amount <= 10)

        minimum = total_amount;

    else if (10 < total_amount * .01)

        minimum = total_amount * .01;

    else
      minimum = 10;

    return minimum;

}

