/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 19, 2018, 5:03 PM
 */

#include <iostream>
using namespace std;

int toFahrenheit( int celsius )
{

return ( ( 9.0 / 5 ) * celsius + 32 );

}

int main()
{
int celsius;
int fahrenheit;

celsius = 100;
while ( ( fahrenheit = toFahrenheit( celsius ) ) != celsius ) celsius--;

std::cout << "celsius = " << celsius
<< ", fahrenheit = " << fahrenheit
<< std::endl;

return 0;
}
