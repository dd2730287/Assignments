/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 11, 2018, 5:25 PM
 */

#include <iostream>

using namespace std;
int main() {
    
    double mph {0};
    cout << "Please enter miles per hour \"mph\" . \n";
    if ( (std::cin >> mph) && (0.0 < mph) ) {
      cout << "Ok\n\n";
      const int all_sec = static_cast < int > (3600.0 / mph);
      const int minute = all_sec / 60;
      const int second = all_sec % 60;
      cout << "Your answer is " << minute << " minutes and " << second << " seconds\n";
      
    }
            

    return 0;
}

