/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 11, 2018, 5:43 PM
 */

#include <iostream>
#include <string>

using namespace std;

int main() {
    
    string instructor, Name, food, adjective, color, animal;
    double number;
    
    cout << "Enter your instructor name: \n";
    cin >> instructor;
    
    cout << "Enter your name:\n";
    cin >> Name;
    
    cout << "Enter a food:\n";
    cin >> food;
    
    cout << "Enter a number between 100 and 120:\n";
    cin >> adjective;
    
    cout << "Enter a color:\n";
    cin >> color;
    
    cout << "Enter an animal:\n";
    cin >> animal;
    
    
    cout << "Dear Instructor " << instructor << ",";
    cout << "\n\n I am sorry that I am unable to turn in my homework at this time. \n First, I ate a rotten " << food ;
    cout << " ,which made me turn " << color << " and extremely ill. \n I came down with a fever of " << adjective ;
    cout << " .Next, my " << color << " pet " << animal ;
    cout << " must have smelled the remains of the " << food << " on my homework, because he ate it.";
    cout << "I am currently rewriting my homework and hope you will accept it late.";
    cout << "\n\n\t\t\t\t\tSincerely, " << "\n\t\t\t\t\t" << Name << endl;
    
    

    return 0;
}

