/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 12, 2018, 5:25 PM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
char chagain=' ';
do{
const double chocolatecalories=230;

double BMR;
double weight;
double height;
int age;
char gender;
 
cout<<"Enter weight in kilograms: ";
cin>>weight;
cout<<"Height in centimeters: ";
cin>>height;
cout<<"Age in years: ";
cin>>age;
cout<<"Character M for male and F for female: ";
cin>>gender;
if(gender=='M' || gender=='m'){

BMR = 66 +(13.7 * weight) + ( 5 * height) 
-
( 6.8 * age );
}
else if(gender=='F' || gender=='f'){

BMR = 655 + ( 9.6 * weight ) + ( 1.8 * height ) 
-
( 4.7 * age );
}else{
cout<<"No such gender \n";
}

int numberofchocolatebar;

numberofchocolatebar= BMR/chocolatecalories;
cout<<"The number of chocolate bars are: "<<numberofchocolatebar<<"\n \n";
cout<<"Would like to run program again(y/n):";
cin>>chagain;
}while(chagain=='y');
system("PAUSE");
return 0;//
}
