/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 11, 2018, 6:03 PM
 */

#include <iostream>

using namespace std;

int main() {
    
    int number;
    int roomcapacity;
    char choice ; 
    do {
        
        cout << "Enter the room capacity :";
        cin >> roomcapacity;
        cout << "Enter number of people in the meeting :";
        cin >> number;
        
        if (number <= roomcapacity)
            cout << "You can hold the meeting legally!";
        else if (number > roomcapacity)
        {
    cout << "Warning! You can't hold the meeting." << endl;
    cout << "But if you still want to hold the meeting, you have to exclude: " << (number - roomcapacity) << " guest(s)"; 
        }
        
        cout << endl << endl << "Do you want to run the program again? <y/n> ";
        cin >> choice;
        cout << endl << endl;
    }
    
    while ( choice == 'y' || choice == 'Y');
    
    cout << "\nEnd of program\n\n";
    return 0;
}

