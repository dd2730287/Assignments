/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 12, 2018, 5:09 PM
 */

#include <iostream>

using namespace std;

int main() {
    
    double start;
    double end;
    double velocity;
    
    cout << "Enter the starting temperature: ";
    
    cin >> start;
    
    cout << "Enter the ending temperature: ";
    cin >> end;
    
    while (start <=end)
    {
        velocity = 331.3 + 0.61 * start;
        cout << "at " << start << " degrees Celsius the velocity of sound is " << velocity << "m/s" << endl;
        start++;
    }
    

    return 0;
}

