/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 11, 2018, 4:58 PM
 */

#include <iostream>

using namespace std;
#define matriction 35273.92

int main () {
    
    double ounceses, weight, boxes;
    char choice;
    
    {
        cout << "Enter weight of package in ounce: ";
        cin >> ounceses;
        
        weight = (ounceses/matriction);
        cout << "Weight of packet in metric tons is " << weight << "\n";
        
        boxes = (matriction/ounceses);
        cout << "Number of boxes to make metric:" << boxes << "\n";
        
        cout << "Press y or Y to continue" << endl;
        cin >> choice;
    } while (choice == 'Y' || choice == 'y' );
    
    system ("pause");
    

    return 0;
}

