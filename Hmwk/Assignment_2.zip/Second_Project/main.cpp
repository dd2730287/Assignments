/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 11, 2018, 5:13 PM
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    
    long n;
    int i;
    double r,guess;
    
    cout << "Enter number: ";
    cin >> n;
    guess = n/2.00;
    for (i=1;i<=5;++i) {
        
        r = n / guess;
        guess = (guess + r) / 2;
        }
    
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    
    cout << endl;
    cout << "The square root of " << n << " is approximately " << guess << endl << endl;
    

    return 0;
}

