/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Daniel Dunn
 *
 * Created on March 12, 2018, 5:55 PM
 */

#include <iostream>
using namespace std;
int main()
{
    char x;
    double total_int_paid, pay_duration, total_months, remaining_debt, cost=1000;
    int c=0; 
    const int monthly_pay=50;
    const double monthly_interest=.015;
    
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    
    cout<<"You brought a stereo system that is $1000 with a 1.5% interest per month and \n";
    cout<<"monthly payments of $50\n";
    cout<<"stereo system is $1000\n"<<"monthly interest is 1.5%\n"<<"monthly payment is $50\n";
    remaining_debt = cost; 
    while (remaining_debt>50)
    {
      remaining_debt -= monthly_pay - (remaining_debt*monthly_interest); 
      c++;
    }
    cout<<remaining_debt<<endl;
    cout<<c;
    cin>>x;
    
    return 0;
}