/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 3, 2018, 6:16 PM
 */

#include <iostream>

using namespace std;

int main( ) {
    
    int quarters, dimes, nickels, total_cents;
    cout << "Enter the number of quarters:\n";
    cin >> quarters;
    cout << "Enter the number of dimes:\n";
    cin >> dimes;
    cout << "Enter the number of nickels:\n";
    cin >> nickels;
    total_cents = (quarters * 25) + (dimes * 10) + (nickels * 5);
    cout << total_cents;
    
    return 0;
}

