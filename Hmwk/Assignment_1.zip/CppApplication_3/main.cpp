/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 1, 2018, 3:14 PM
 */

#include <iostream>

using namespace std;//namespace I/O stream library created



//User Libraries



//Global Constants

//Math, Physics, Science, Conversions, 2-D Array Columns



//Function Prototypes



//Execution Begins Here!

int main(int argc, char** argv) {

    //Declare Variables

    char x;



    //Prompt for the variable value

    cout<<"Type in a character utilized to output the Big C"<<endl;

    cin>>x;



    //Display Outputs

    cout<<"  "<<x<<x<<x<<endl;

    cout<<" "<<x<<"   "<<x<<endl;

    cout<<x<<endl;

    cout<<x<<endl;

    cout<<x<<endl;

    cout<<x<<endl;

    cout<<x<<endl;

    cout<<" "<<x<<"   "<<x<<endl;

    cout<<"  "<<x<<x<<x<<endl;

    

    //Exit program!

    return 0;

}