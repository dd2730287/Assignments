/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 3, 2018, 5:21 PM
 */

#include <iostream>

using namespace std;

int main( ) {
    
    for (int i = 0; i < 40; i++) {
      cout << "*";
    }
    
    cout << "\n";
    cout << "\n";
    
    cout << "    CCC          " << "     SSSS     !!\n";
    cout << "  C      C       " << "    S    S    !!\n";
    cout << " C               " << "   S          !!\n";
    cout << "C                " << "    S         !!\n";
    cout << "C                " << "     SSSS     !!\n";
    cout << "C                " << "         S    !!\n";
    cout << " C               " << "          S   !!\n";
    cout << "  C      C       " << "    S    S    !!\n";
    cout << "    CCC          " << "     SSSS     !!\n";
    
    cout << "\n";
    for (int i = 0; i < 40; i++) {
        cout << "*";
    }
    cout << "\n";
    cout << "Computer Science is Cool Stuff!!!";
    
    return 0;
}

