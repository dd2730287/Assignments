/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: skull
 *
 * Created on March 3, 2018, 6:38 PM
 */

#include <iostream>
#include <cmath>

using namespace std;

int main() {

    double acceleration = 32;
    double time;
    
    cout << "This is a program that calculates how far an object will fall in" << endl;
    cout << "user specified seconds." << endl;
    cout << "Enter the number of seconds." << endl;
    
    cin >> time;
    
    double timePow = pow(time, 2.0);
    double distance = (acceleration * timePow)/2;
    
    cout << endl << distance;
    
    char letter;
    cout << endl << "Enter a letter to end the program" << endl;
    cin >> letter;
   
    return 0;
}

